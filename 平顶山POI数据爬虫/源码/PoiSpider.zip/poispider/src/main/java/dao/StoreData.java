package dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import entity.Information;
import util.DBHelper;

public class StoreData {
	
	
	public boolean storeData(Information info, String tablename){
		Connection conn = null;
		PreparedStatement pst = null;

		try {
			conn = DBHelper.getConnection();
			String sql = "insert into "+tablename+"(firsttype, secondtype, thirdtype, typecode, name_p, address, province, city, area, lat, lng, telephone, tag) values(?,?,?,?,?,?,?,?,?,?,?,?,?);";
			pst = conn.prepareStatement(sql);
			pst.setString(1, info.getFirsttype());
			pst.setString(2, info.getSecondtype());
			pst.setString(3, info.getThirdtype());
			pst.setString(4, info.getTypecode());
			pst.setString(5, info.getName());
			pst.setString(6, info.getAddress());
			pst.setString(7, info.getProvince());
			pst.setString(8, info.getCity());
			pst.setString(9, info.getArea());
			pst.setString(10, info.getLat());
			pst.setString(11, info.getLng());
			pst.setString(12, info.getTelephone());
			pst.setString(13, info.getTag());
			
			if(!pst.execute()){
				return true;
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (pst != null){
				try {
					pst.close();
					pst = null;
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
//			if(conn != null){
//				try {
//					conn.close();
//					conn = null;
//				} catch (SQLException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				}
//			}

		}
		return false;
	}
	
	
	
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Information info = new Information(1, "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14");
		System.out.println(info.toString());
		String tablename = "foodservicedata";
		StoreData storeData = new StoreData();
		boolean bool = storeData.storeData(info, tablename);
		if(bool){
			System.out.println("存储成功！");
		}
	}

}
