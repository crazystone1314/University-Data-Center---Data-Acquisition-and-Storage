package dao;

import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import entity.Information;

public class ParseJson {
	
	
	
	
	public Information getData(String content) throws JSONException{
		
		Information info = null;
		JSONObject jsonObject = new JSONObject(content);
			
		
		String type = null;
		String typecode = null;
		String name = null;
		String address = null;
		String province = null;
		String city = null;
		String area = null;
		String lat = null;
		String lng = null;
		String telephone = null;
		String tag = null;
		
		
		if(!jsonObject.isNull("typecode")){
			typecode = jsonObject.getString("typecode");
		}else{
			typecode = "null";
		}
		if(!jsonObject.isNull("name")){
			name = jsonObject.getString("name");
		}else{
			name = "null";
		}
		if(!jsonObject.isNull("address")){
			address = jsonObject.getString("address");
			//System.out.println(address);
		}else{
			address = "null";
		}
		if(!jsonObject.isNull("pname")){
			province = jsonObject.getString("pname");
			//System.out.println(province);
		}else{
			province = "null";
		}
		if(!jsonObject.isNull("cityname")){
			city = jsonObject.getString("cityname");
			//System.out.println(city);
		}else{
			city = "null";
		}
		if(!jsonObject.isNull("adname")){
			area = jsonObject.getString("adname");
			//System.out.println(area);
		}else{
			area = "null";
		}
		if(!jsonObject.isNull("location")){
			String locations[] = jsonObject.getString("location").split(",");
			lat = locations[0];
			lng = locations[1];
			//System.out.println(lat+ " "+lng);
		}else{
			lat = "null";
			lng = "null";
		}
		if(!jsonObject.isNull("tel")){
			telephone = jsonObject.getString("tel");
		}else{
			telephone = "null";
		}
		if(!jsonObject.isNull("tag")){
			tag = jsonObject.getString("tag");
			//System.out.println(tag);
		}else{
			tag = "null";
		}
		if(!jsonObject.isNull("type")){
			type = jsonObject.getString("type");
			if(type.contains("|")){
				String type_two[] = type.split("|");
				for(int i = 0; i < type_two.length; i++){
					String type_three[] = type_two[i].split(";");
					info = new Information();
					info.setFirsttype(type_three[0]);
					info.setSecondtype(type_three[1]);
					info.setThirdtype(type_three[2]);
					info.setTypecode(typecode);
					info.setName(name);
					info.setAddress(address);
					info.setProvince(province);
					info.setCity(city);
					info.setArea(area);
					info.setLat(lat);
					info.setLng(lng);
					info.setTelephone(telephone);
					info.setTag(tag);
					
					return info;
				}
//				String type_three[] = type_two[0].split(";");
//				info = new Information();
//				info.setFirsttype(type_three[0]);
//				info.setSecondtype(type_three[1]);
//				info.setThirdtype(type_three[2]);
//				info.setTypecode(typecode);
//				info.setName(name);
//				info.setAddress(address);
//				info.setProvince(province);
//				info.setCity(city);
//				info.setArea(area);
//				info.setLat(lat);
//				info.setLng(lng);
//				info.setTelephone(telephone);
//				info.setTag(tag);
			}else{
				String type_three[] = type.split(";");
				info = new Information();
				info.setFirsttype(type_three[0]);
				info.setSecondtype(type_three[1]);
				info.setThirdtype(type_three[2]);
				info.setTypecode(typecode);
				info.setName(name);
				info.setAddress(address);
				info.setProvince(province);
				info.setCity(city);
				info.setArea(area);
				info.setLat(lat);
				info.setLng(lng);
				info.setTelephone(telephone);
				info.setTag(tag);
				return info;
			}
		}else{
			type = "null";
		}
		
		return info;
		
	}
	
	
	public ArrayList<Information> parseJsonData(String content){
		JSONObject jsonObject = null;
		ArrayList<Information> list = new ArrayList<Information>();
		
		try {
			jsonObject = new JSONObject(content);
			
			JSONArray array = jsonObject.getJSONArray("pois");
			for(int i = 0; i < array.length(); i++){
				list.add(getData(array.get(i).toString()));
			}
			
		} catch (JSONException e) {
			e.printStackTrace();
		}
		
		return list;
		
	}
	
	public static void main(String[] args) {
		
	
	}

}
