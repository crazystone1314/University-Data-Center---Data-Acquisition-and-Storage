package dao;

import org.json.JSONException;
import org.json.JSONObject;

import us.codecraft.webmagic.Page;
import us.codecraft.webmagic.Site;
import us.codecraft.webmagic.Spider;
import us.codecraft.webmagic.processor.PageProcessor;

public class PageCountRepoPageProcessor implements PageProcessor {

	private Site site = Site.me().setRetryTimes(3).setSleepTime(1000);
	private int num;
	
	
	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}

	@Override
	public void process(Page page) {
		// TODO Auto-generated method stub

		String content = page.getJson().toString();
		try {
			JSONObject jsonObject = new JSONObject(content);
			String str_count = jsonObject.getString("count");
			int count = Integer.parseInt(str_count);
			this.num = (int)Math.floor(count/20);
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	@Override
	public Site getSite() {
		// TODO Auto-generated method stub
		return site;
	}
	
	
	public static void main(String[] args){
		
		PageCountRepoPageProcessor pcrpp = new PageCountRepoPageProcessor();
	
		Spider.create(pcrpp)
        //从URL开始抓
        .addUrl("http://restapi.amap.com/v3/place/text?&keywords=餐饮服务&city=pingdingshan&output=json&offset=20&page=1&key=7a376014208c8d2830fb8b37283f0eec&extensions=all")
        //开启5个线程抓取
        .thread(1)
        //启动爬虫
        .run();	
		
		System.out.println(pcrpp.getNum());
	
	}

}
