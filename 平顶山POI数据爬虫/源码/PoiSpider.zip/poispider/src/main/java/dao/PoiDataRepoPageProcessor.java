package dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import entity.BasicSetting;
import entity.Information;
import us.codecraft.webmagic.Page;
import us.codecraft.webmagic.Site;
import us.codecraft.webmagic.Spider;
import us.codecraft.webmagic.processor.PageProcessor;

public class PoiDataRepoPageProcessor implements PageProcessor {

	// 部分一：抓取网站的相关配置，包括编码、抓取间隔、重试次数等
	private Site site = Site.me().setRetryTimes(3).setSleepTime(1000);
	private String tablename;
	//private boolean flag;
	
//	public boolean isFlag() {
//		return flag;
//	}
//
//	public void setFlag(boolean flag) {
//		this.flag = flag;
//	}

	public String getTablename() {
		return tablename;
	}

	public void setTablename(String tablename) {
		this.tablename = tablename;
	}

	// process是定制爬虫逻辑的核心接口，在这里编写抽取逻辑
	@Override
	public void process(Page page) {
		String content = page.getJson().toString();
		//System.out.println(page.getJson().toString());
		
		ParseJson parseJson = new ParseJson();
		StoreData storeData = new StoreData();
		ArrayList<Information> list = parseJson.parseJsonData(content);
//		if(list.isEmpty()){
//			//停止爬取
//			this.flag = true;
//		}
		for(Information info : list){
			System.out.println(info.toString());
			boolean bool = storeData.storeData(info, this.tablename);
			if(bool){
				System.out.println("存储成功！");
			}
		}
		

		 // 部分二：定义如何抽取页面信息，并保存下来
		// 部分三：从页面发现后续的url地址来抓取
	}

	@Override
	public Site getSite() {
		// TODO Auto-generated method stub
		return site;
	}

	
	
	
	public PoiDataRepoPageProcessor(){}
	public PoiDataRepoPageProcessor(String tablename){
		this.tablename = tablename;
		//this.flag = false;
	}
	
	
	
	
	public void startSpider() {

		BasicSetting basicSetting = new BasicSetting();
		String province = basicSetting.getProvince();
		String ak = basicSetting.getAk();
		Map map = basicSetting.createTypeMap();
		Set set = map.keySet();
		Iterator iter = set.iterator();
		while (iter.hasNext()) {
			String key = iter.next().toString();
			String value = map.get(key).toString();
			PageCountRepoPageProcessor pcrpp = new PageCountRepoPageProcessor();
			PoiDataRepoPageProcessor pd = new PoiDataRepoPageProcessor(value);
			Spider.create(pcrpp)
					// 从URL开始抓
					.addUrl("http://restapi.amap.com/v3/place/text?&keywords=" + key + "&city=" + province
							+ "&output=json&offset=20&page=1&key=" + ak + "&extensions=all")
					// 开启1个线程抓取
					.thread(1)
					// 启动爬虫
					.run();

			int num = pcrpp.getNum();

			for (int i = 0; i < num+1; i++) {
				Spider.create(pd)
						// 从URL开始抓
						.addUrl("http://restapi.amap.com/v3/place/text?&keywords=" + key + "&city=" + province
								+ "&output=json&offset=20&page=" + i + "&key=" + ak + "&extensions=all")
						// 开启5个线程抓取
						.thread(1)
						// 启动爬虫
						.run();
			}
			
			System.out.println(key+" : 一共有"+num+"页, 爬取完毕！");

		}

	}
	
	
	
	
//	public void startSpider(){
//		BasicSetting basicSetting = new BasicSetting();
//		String province = basicSetting.getProvince();
//		String ak = basicSetting.getAk();
//		Map map = basicSetting.createTypeMap();
//		Set set = map.keySet();
//		Iterator iter = set.iterator();
//		while(iter.hasNext()){
//			String key = iter.next().toString();
//			String value = map.get(key).toString();
//			int i = 1;
//			PoiDataRepoPageProcessor pd = new PoiDataRepoPageProcessor(value);
//			while(!pd.isFlag()){
//			Spider.create(pd)
//	        //从URL开始抓
//	        .addUrl("http://restapi.amap.com/v3/place/text?&keywords="+key+"&city="+province+"&output=json&offset=20&page="+i+"&key="+ak+"&extensions=all")
//	        //开启5个线程抓取
//	        .thread(1)
//	        //启动爬虫
//	        .run();
//			i++;
//			}
//		}
//		
//	}
//	
	
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

//		int i = 1;
//		PoiDataRepoPageProcessor pd = new PoiDataRepoPageProcessor("foodservicedata");
//		while(!pd.isFlag()){
//		Spider.create(pd)
//        //从URL开始抓
//        .addUrl("http://restapi.amap.com/v3/place/text?&keywords=餐饮服务&city=pingdingshan&output=json&offset=20&page="+i+"&key=7a376014208c8d2830fb8b37283f0eec&extensions=all")
//        //开启5个线程抓取
//        .thread(1)
//        //启动爬虫
//        .run();
//		i++;
//		}
		PoiDataRepoPageProcessor pdrpp = new PoiDataRepoPageProcessor();
		pdrpp.startSpider();
		
		
	}

}
