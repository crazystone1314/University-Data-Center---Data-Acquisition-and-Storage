package entity;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class BasicSetting {
	
	private static final String AK = "3d54c7aa31c6e0f428638892fa0bde3e";
	private static final String PROVINCE = "xuchang";
	private static final String[] TYPE = {"汽车维修", "汽车销售", "商务住宅", "生活服务","事件活动", "室内设施", 
			"体育休闲服务","通行设施", "医疗保健服务", "政府机构及社会团体","住宿服务", "科教文化服务", "摩托车服务","汽车服务", 
			"餐饮服务", "道路附属设施","地名地址信息", "风景名胜", "公共设施","公司企业", "购物服务", "交通设施服务","金融保险服务", "科技文化服务"};
	private static final String[] TYPECODE = {"autmai", "autsal", "comres", "lifser", "eveact", "indfac", "spoleiser", 
			"trafac", "heacarser", "govageandsocgro","accser", "scieduculser", "motser", "autser", "fooserdat", 
			"roaancfac", "locinfofgeonam", "beaspo", "pubfac", "corent","shoser", "trafacser", "fininsser", "sciandtecculser"};
	
	
	public HashMap createTypeMap(){
		HashMap map = new HashMap();
		for(int i = 0; i < TYPE.length; i++){
			map.put(TYPE[i], TYPECODE[i]);
		}
		return map;
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		BasicSetting bs = new BasicSetting();
		
		Map m = bs.createTypeMap();
		
		Set set = m.keySet();
		Iterator iter = set.iterator();
		while(iter.hasNext()){
			String key = iter.next().toString();
			System.out.println(key+ "  " +m.get(key));
		}
	}


	
	
	
	public static String getAk() {
		return AK;
	}


	public static String getProvince() {
		return PROVINCE;
	}

}
