package entity;

public class Information {
	
	private int id;
	private String firsttype;
	private String secondtype;
	private String thirdtype;
	private String typecode;
	private String name;
	private String address;
	private String province;
	private String city;
	private String area;
	private String lat;
	private String lng;
	private String telephone;
	private String tag;
	
	
	

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}


	public String getFirsttype() {
		return firsttype;
	}

	public void setFirsttype(String firsttype) {
		this.firsttype = firsttype;
	}


	public String getSecondtype() {
		return secondtype;
	}

	public void setSecondtype(String secondtype) {
		this.secondtype = secondtype;
	}


	public String getThirdtype() {
		return thirdtype;
	}


	public void setThirdtype(String thirdtype) {
		this.thirdtype = thirdtype;
	}

	public String getTypecode() {
		return typecode;
	}


	public void setTypecode(String typecode) {
		this.typecode = typecode;
	}


	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}


	public String getAddress() {
		return address;
	}



	public void setAddress(String address) {
		this.address = address;
	}




	public String getProvince() {
		return province;
	}



	public void setProvince(String province) {
		this.province = province;
	}



	public String getCity() {
		return city;
	}



	public void setCity(String city) {
		this.city = city;
	}



	public String getArea() {
		return area;
	}



	public void setArea(String area) {
		this.area = area;
	}


	public String getLat() {
		return lat;
	}



	public void setLat(String lat) {
		this.lat = lat;
	}



	public String getLng() {
		return lng;
	}



	public void setLng(String lng) {
		this.lng = lng;
	}



	public String getTelephone() {
		return telephone;
	}



	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}


	public String getTag() {
		return tag;
	}


	public void setTag(String tag) {
		this.tag = tag;
	}



	
	public String toString(){
		return "Information : [id: "+this.id+" firsttype: "+this.firsttype+" secondtype: "
	+this.secondtype+" thirdtype: "+this.thirdtype+" typecode: "+this.typecode+" name: "+this.name
	+" address: "+this.address+" province: "+this.province+" city: "+this.city+" area: "+this.area
	+" lat: "+this.lat+" lng: "+this.lng+" telephone: "+this.telephone+" tag: "+this.tag+"]";
	}
	
	
	
	public Information(){}
	public Information(int id, String firsttype, String secondtype, String thirdtype, 
			String typecode, String name, String address, String province, 
			String city, String area, String lat, String lng, String telephone, String tag){
		
		this.id = id;
		this.firsttype = firsttype;
		this.secondtype = secondtype;
		this.thirdtype = thirdtype;
		this.typecode = typecode;
		this.name = name;
		this.address = address;
		this.province = province;
		this.city = city;
		this.area = area;
		this.lat = lat;
		this.lng = lng;
		this.telephone = telephone;
		this.tag = tag;
	}
	
	
	
	
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Information info = new Information(1, "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14");
		System.out.println(info.toString());
	}

}
